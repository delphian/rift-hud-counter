AOMRift
================

Helper functions for writing a Rift addon in lua.